-- MariaDB dump 10.19  Distrib 10.11.11-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: db
-- ------------------------------------------------------
-- Server version	10.11.11-MariaDB-ubu2204-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `backend_layout`
--

DROP TABLE IF EXISTS `backend_layout`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `backend_layout` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `config` longtext DEFAULT NULL,
  `icon` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backend_layout`
--

LOCK TABLES `backend_layout` WRITE;
/*!40000 ALTER TABLE `backend_layout` DISABLE KEYS */;
/*!40000 ALTER TABLE `backend_layout` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_dashboards`
--

DROP TABLE IF EXISTS `be_dashboards`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_dashboards` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `cruser_id` int(10) unsigned NOT NULL DEFAULT 0,
  `widgets` text DEFAULT NULL,
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `identifier` (`identifier`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_dashboards`
--

LOCK TABLES `be_dashboards` WRITE;
/*!40000 ALTER TABLE `be_dashboards` DISABLE KEYS */;
INSERT INTO `be_dashboards` VALUES
(1,0,1776096201,1776096201,0,0,0,0,1,'{\"18158e68193fe2d724001079c1b02e9bbbf63d2a\":{\"identifier\":\"t3information\"},\"f5d26c39fa097d8f1103043bf2bf0d248c4f9430\":{\"identifier\":\"docGettingStarted\"}}','2cc4b374158bc6f1a1a9500c679055fc1876dc19','My dashboard');
/*!40000 ALTER TABLE `be_dashboards` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_groups`
--

DROP TABLE IF EXISTS `be_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tables_select` longtext DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pagetypes_select` longtext DEFAULT NULL,
  `tables_modify` longtext DEFAULT NULL,
  `non_exclude_fields` longtext DEFAULT NULL,
  `explicit_allowdeny` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `custom_options` longtext DEFAULT NULL,
  `groupMods` longtext DEFAULT NULL,
  `mfa_providers` longtext DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `category_perms` longtext DEFAULT NULL,
  `availableWidgets` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_groups`
--

LOCK TABLES `be_groups` WRITE;
/*!40000 ALTER TABLE `be_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_sessions`
--

DROP TABLE IF EXISTS `be_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` longblob DEFAULT NULL,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_sessions`
--

LOCK TABLES `be_sessions` WRITE;
/*!40000 ALTER TABLE `be_sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `be_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `be_users`
--

DROP TABLE IF EXISTS `be_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `be_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `uc` mediumblob DEFAULT NULL,
  `user_settings` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`user_settings`)),
  `workspace_id` int(11) NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `password_reset_token` varchar(128) NOT NULL DEFAULT '',
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `avatar` int(10) unsigned NOT NULL DEFAULT 0,
  `db_mountpoints` longtext DEFAULT NULL,
  `file_mountpoints` varchar(255) DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `realName` varchar(80) NOT NULL DEFAULT '',
  `admin` smallint(5) unsigned NOT NULL DEFAULT 0,
  `options` smallint(5) unsigned NOT NULL DEFAULT 3,
  `file_permissions` longtext DEFAULT NULL,
  `workspace_perms` smallint(5) unsigned NOT NULL DEFAULT 1,
  `lang` varchar(10) NOT NULL DEFAULT 'en',
  `userMods` longtext DEFAULT NULL,
  `allowed_languages` varchar(255) NOT NULL DEFAULT '',
  `TSconfig` longtext DEFAULT NULL,
  `tsconfig_includes` varchar(255) DEFAULT '',
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `category_perms` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `username` (`username`),
  KEY `parent` (`pid`,`deleted`,`disable`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `be_users`
--

LOCK TABLES `be_users` WRITE;
/*!40000 ALTER TABLE `be_users` DISABLE KEYS */;
INSERT INTO `be_users` VALUES
(1,0,1776096003,1776096003,0,0,0,0,NULL,'a:6:{s:10:\"moduleData\";a:12:{s:28:\"dashboard/current_dashboard/\";s:40:\"2cc4b374158bc6f1a1a9500c679055fc1876dc19\";s:10:\"web_layout\";a:3:{s:8:\"viewMode\";i:1;s:10:\"showHidden\";b:1;s:9:\"languages\";a:1:{i:0;i:0;}}s:7:\"records\";a:4:{s:9:\"clipBoard\";b:1;s:9:\"searchBox\";b:0;s:15:\"collapsedTables\";a:0:{}s:9:\"languages\";a:1:{i:0;i:0;}}s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";a:0:{}s:6:\"web_ts\";a:1:{s:6:\"action\";s:25:\"web_typoscript_infomodify\";}s:12:\"pagetsconfig\";a:1:{s:6:\"action\";s:21:\"pagetsconfig_includes\";}s:25:\"web_typoscript_infomodify\";a:2:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}s:9:\"languages\";a:1:{i:0;i:0;}}s:17:\"typoscript_active\";a:7:{s:18:\"sortAlphabetically\";b:1;s:28:\"displayConstantSubstitutions\";b:1;s:15:\"displayComments\";b:1;s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}s:18:\"constantConditions\";a:0:{}s:15:\"setupConditions\";a:0:{}s:9:\"languages\";a:1:{i:0;i:0;}}s:23:\"web_typoscript_analyzer\";a:2:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}s:9:\"languages\";a:1:{i:0;i:0;}}s:29:\"web_typoscript_constanteditor\";a:3:{s:23:\"selectedTemplatePerPage\";a:1:{i:1;i:-1;}s:16:\"selectedCategory\";s:0:\"\";s:9:\"languages\";a:1:{i:0;i:0;}}s:10:\"system_log\";a:1:{s:10:\"constraint\";s:337:\"O:39:\"TYPO3\\CMS\\Belog\\Domain\\Model\\Constraint\":11:{s:14:\"\0*\0userOrGroup\";s:1:\"0\";s:9:\"\0*\0number\";i:20;s:15:\"\0*\0workspaceUid\";i:-99;s:10:\"\0*\0channel\";s:3:\"php\";s:8:\"\0*\0level\";s:5:\"debug\";s:17:\"\0*\0startTimestamp\";i:0;s:15:\"\0*\0endTimestamp\";i:0;s:18:\"\0*\0manualDateStart\";N;s:17:\"\0*\0manualDateStop\";N;s:9:\"\0*\0pageId\";i:0;s:8:\"\0*\0depth\";i:0;}\";}s:19:\"web_FormFormbuilder\";a:1:{s:6:\"action\";s:11:\"form_editor\";}}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";s:15:\"moduleSessionID\";a:12:{s:28:\"dashboard/current_dashboard/\";s:40:\"3ab7b4b12079b6309c59cd687339eebe3ee5ad2d\";s:10:\"web_layout\";s:40:\"5f2111e8f16a6ffb8297a0d906297f62f38b761e\";s:7:\"records\";s:40:\"5f2111e8f16a6ffb8297a0d906297f62f38b761e\";s:57:\"TYPO3\\CMS\\Backend\\Utility\\BackendUtility::getUpdateSignal\";s:40:\"3ab7b4b12079b6309c59cd687339eebe3ee5ad2d\";s:6:\"web_ts\";s:40:\"e0f7903ab7383bfd07b5ea148b8b8f3a65c7dc33\";s:12:\"pagetsconfig\";s:40:\"3ab7b4b12079b6309c59cd687339eebe3ee5ad2d\";s:25:\"web_typoscript_infomodify\";s:40:\"3ab7b4b12079b6309c59cd687339eebe3ee5ad2d\";s:17:\"typoscript_active\";s:40:\"3ab7b4b12079b6309c59cd687339eebe3ee5ad2d\";s:23:\"web_typoscript_analyzer\";s:40:\"3ab7b4b12079b6309c59cd687339eebe3ee5ad2d\";s:29:\"web_typoscript_constanteditor\";s:40:\"3ab7b4b12079b6309c59cd687339eebe3ee5ad2d\";s:10:\"system_log\";s:40:\"9700ec31ddc834419a2316bb5f159d932321b6a7\";s:19:\"web_FormFormbuilder\";s:40:\"e02b5c1e882698632c3a56325151766ad1f6a180\";}s:17:\"systeminformation\";s:40:\"{\"system_log\":{\"lastAccess\":1779055339}}\";}','{\"emailMeAtLogin\":0,\"titleLen\":50,\"edit_docModuleUpload\":\"1\"}',0,NULL,'','mir','$argon2i$v=19$m=65536,t=16,p=1$VHJROUhEaXJTYUU4NDNlcw$8UYguPckj6kLQwz1Uduw67VghAvhHuuKflSxo2Y2DXo','',0,NULL,'','a@a.de','',1,3,NULL,1,'en',NULL,'',NULL,'',1779086094,NULL),
(2,0,1778571709,1778571709,0,0,0,0,NULL,'a:4:{s:10:\"moduleData\";a:0:{}s:14:\"emailMeAtLogin\";i:0;s:8:\"titleLen\";i:50;s:20:\"edit_docModuleUpload\";s:1:\"1\";}','{\"emailMeAtLogin\":0,\"titleLen\":50,\"edit_docModuleUpload\":\"1\"}',0,NULL,'','_cli_','$argon2i$v=19$m=65536,t=16,p=1$ZmpFSEx1QmJNZEhGNWptdg$hmrT23S13gQ/xHE/IvmZO8vZzULen07mr2hdMoEkWLY','',0,NULL,'','','',1,3,NULL,1,'en',NULL,'',NULL,'',0,NULL);
/*!40000 ALTER TABLE `be_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash`
--

DROP TABLE IF EXISTS `cache_hash`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash`
--

LOCK TABLES `cache_hash` WRITE;
/*!40000 ALTER TABLE `cache_hash` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_hash_tags`
--

DROP TABLE IF EXISTS `cache_hash_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_hash_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_hash_tags`
--

LOCK TABLES `cache_hash_tags` WRITE;
/*!40000 ALTER TABLE `cache_hash_tags` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_hash_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages`
--

DROP TABLE IF EXISTS `cache_pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages`
--

LOCK TABLES `cache_pages` WRITE;
/*!40000 ALTER TABLE `cache_pages` DISABLE KEYS */;
INSERT INTO `cache_pages` VALUES
(1,'1_2e1b17ebfc2ed006',1779211525,'x���[�F����K�C�\ZI�凰ݣ���(8o��Vk{�^�ր���̮$K�P\'w�Kӣ-H�3��4%�Uw>�N��c2a��ӷ�cm�\Z���B���ݨ;z��\'G;��ǻ�T�`��4��������S��\Z��&�F�$I���31�u\0b��}��m�m4�v�ܔ��e]��y�;�����V�x��<��D�Y�L��=�=�K�#�8aL�bji4K(�v��	A�\0/���(�D�����\ZM���$�Y��~$$�F\Z	=�甅)��B��_\Z��/6KG�(�\'|2���vju��Ң�2�Mm�\Z�Iy�	+���2�h	*�%r�$�c��8J\"\0O��H�;S� ��11���f�L��Z\r���\\�l�4\nX�P��!(��O�@D��Zf㾮d�9@���)���b�tʘеi��}](X$ӦMS�mZ6��&��xܱl�n�\rӭ�-ӴǴ�	@?[�v��\Z]S��q����ȍ걔�Q�)��Si5TK��y�r�ǐNe(�빑7����rD�C���m_z5ܲDW^�?�b���8�Ը𖞣�ч4���1��\"���/v���d�D�,�Q9�����c.$�\0��dI���*��c�����\\)+D|�|\n���\njH�\\WY�W)�z�Kb߿���r�\\��4��$,\'�\0iW\\L�Yv�<�tM�d�)�܅d�QWF\0Β=MFW� �͞��h}ֿ�g�6��]�\0*b��n`h��q�o���X�#\n����P>�#������!PK,5P)�����D�PC]#�7$џ���]m=�Q��\'}(\"��	���eQ�|�%���{���D�OI:���ִ[�z�ձ��ش(���H�r-�]��o�v�ElJ�I�u۬�6���5d\Z��q�\n���C=�3�)���r�guf%��%����S����]У���h�W{����C��i��쾻��EO����k�f��\'���=	�s�ա��͉?���G��9�ZG|��|�K��͡y������){��������K�n�Usx!⣋�6���n\"��m����Mݧ�|:�ߎ�+�����w�!l�l6[�&s[c�nX�n�ƌ�:Mӳ̶E���:���I띖�v=�4M�k��+��\\$�\Z����Dp�.����f�ؒ�T�N�t~�)Đ�!�\"���$�~Rx��R:s/�YZeP<���7�o�.�/���gK{KSh��iCm�ယ��y~Ng�\'Cq\\B�����m{Mj�.qY�5[�]w)�y\r�l��r����Ҷ�bn��u�vc��붮��.�r������8�#C���6��3\0w7�$����Th�������a`/J��ChK��w7��YG�����n����\'7AZ�\0�*[�9\\���37D�f�T#��b��2�G��NՃ�.����,�Ue9����o����9RS&]��HM��^~ErEGUdy�&���4�%^l�Ҙ]h�~�qx��?��X�<̴!y\\���r��\'�M#z��~(�If\"��\r��Ж��9�%��N饢��$�Y`��V����!���*5财$-8�t�ژ1�%���g��8K�Q��)G�j�\n�rc�d���2Q��;8U�fl��V}8��\'�1#�E���Ib��{�k��l��I��~D�\"���%o_�o��@��\"�%\Z�䩚b�(�E���f����淙v��\\.ݙ�=�02��E�F���_�-$�ט+J�\'	\'5��\0zHfyߋRT����]�X�f���c�}�f�|�*���S�C�4�g�mA%:���Ժ�.�>;�W�P���^H��}�2K&�&�wp�.��\\U����~/�_\'�����X����}�3rV��E�ט���2��Y+2�ۙ{�,*op���ѯ?8���Z��|{5�Ls�xIYe���z=x�:��ky�� m��ּg�����܆f\nؽ0t\n\n���%>d���@W��$P�����R`����򱽐Tc��D~��U[ ����+:�p���U�<ӝ	������C���5����T^��^B�C|S�\n�uhI/=)ׅ��z��堬����U�����8�	��׹A��|�iB��.�`�+> �7�sw���(\r��\0$�i�\"~�V_�{����\n�*�-Fp.՛�l�$�V1D�f(�����驤�o�t>�fG�r�0�Z`���Mrj\0?!6s�\Z6aԳ�M�t��gכ~m���lRyJ{�~���Z���a��2D��Y��D�S��u�E<}�[�cF����B`�[GN�\'ѳ��ӳ�(ag/p����Q7Lw�H������]��9:%w��!�dL�D��~���+���r�F3h/�\nS��ٺ�NY�Qk��\'_�g{��Ũ��r�斸�34���R��>M���r�\n��i��]����<�@)<��:��!�F���{�ܷ��Q=�	}�&lJ\'�^�G�\'���>�v��w2NGd\"I���P�?󉔌s<�U)�(8;��@8ꑇ�x�r�r@P��(t&2�Fp#&��O�<������T�����R���\"˫x��bX*g��!��3h\\�<�����#g\Z���&�9ajp)5�~	��(C��R�m�v�����^d���P�b��J�%/[��]@�N�����x�gy#��C.����9Ĵ1`ѿ��F@��e�}3rPb�$���95��$]S	��4�e�6/R��qUr*��0�\'~�;M�$\\��z���ć!4D���/L̃|�ĸlI��q��\ZE/\"�p0�>@~�\'�T.�`�Bu/�~��t�dA\0�^���a��$n�e��;�y�8��QH�S����.\ZG� N؄���B���\0JZX�i�9�@��z�]�ɺd�$p���L]RO�~/������r��kj�9Buf�딆�P�L誎�ry+�ˌ�������~B��g�޾���mH�;$�>���ڙS�G�p�yo�4 G�vp��J宬Ҙ�ζ����?u	������O����|V{�Ui\"�,d�9�e�j@�ɻ�,���A�IH|�K%}�����y<�4K��)�$��R�8�o�l�ߗ�B�+ڭ�+`EU�Um�eSs��*�-����2Oqn�.vVrVA�fKΆ.\\4oh�>Zt�v��ͨ�C�����B\'�z����C�}�*�Z�]�x�N��.���\04u��)[h��2;Jȳ]�W�C͹���R��=_I����1o�,T� ����vת��oV°�c��y��\r��q��<���(�	�<�E�2�|@z�!�	����>�I޹9��:k�$�U�ƚ��Vmrr�?6�\'O^<\'��g���3���圿9ٍBr:�����۫�}��4k�Q�Q�fS�c�Y\r?���ai�������ZHd#�1Xz��u���w�c��;ڭ[�\rڽ��[)�');
/*!40000 ALTER TABLE `cache_pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_pages_tags`
--

DROP TABLE IF EXISTS `cache_pages_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_pages_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_pages_tags`
--

LOCK TABLES `cache_pages_tags` WRITE;
/*!40000 ALTER TABLE `cache_pages_tags` DISABLE KEYS */;
INSERT INTO `cache_pages_tags` VALUES
(1,'1_2e1b17ebfc2ed006','tt_content_1'),
(2,'1_2e1b17ebfc2ed006','tt_content_2'),
(3,'1_2e1b17ebfc2ed006','pages_1'),
(4,'1_2e1b17ebfc2ed006','pageId_1');
/*!40000 ALTER TABLE `cache_pages_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline`
--

DROP TABLE IF EXISTS `cache_rootline`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `expires` int(10) unsigned NOT NULL DEFAULT 0,
  `content` longblob DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(180),`expires`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline`
--

LOCK TABLES `cache_rootline` WRITE;
/*!40000 ALTER TABLE `cache_rootline` DISABLE KEYS */;
INSERT INTO `cache_rootline` VALUES
(1,'1__0_0_1_1',1781678333,'x�mT�n�0�}@+���4Es(rqr艠ɑLX��(���;��عIo�yo(�,�0y� ��:���2OZ���g�_�������$�3o6��~���{�rZ�X6y���8��h\rv��:\"SÈqX#�<)@�[.��$MzG���-��*[�]�8<=�W�4d�K��)@�PǬw�/^TҖ�,A��ר�ԊF:�t{l������n�`�\Z0m�bt�G��;8�Q�tO�s=:��.gx�����h=���l9��#C\Zt�\r�#�_�8p���e�Ħݟ����{�������� ��z�n�UO�?0[���\0��x��pX�Ho��\Z[6DXG�!�e#\Zg��$�R�o�N,	:S7pn;��A�x�Kc��6�& ��n��?}Ֆ�Ծ\'}��;�0�@o���\0�lb*�Uru�!����~%/�y|8���w��a.}4���b�nȱ�a���6|��v�*]	a<Ve�1B:9KOoM�_��pz�d���e�J@����H\'�,�q�(<H�q�Q��OC�rB����,��7,���T�<�l��3-FP�P������W0^U9D����\'pZ�:����ʶV�����U�:2�b�|�_���²D�gw�i���ƪ��p�`��D��5�c1�(���4���oI����߸�] ֢5JV�J8��M���W�1l��Yt2ě��t?�n�Ł7I�MI�\'ӿ�ϣ,�'),
(2,'1__0_0_0_0',1781717125,'x�mT�n�0�}@+���4Es(rqr艠ɑLX��(���;��عIo�yo(�,�0y� ��:���2OZ���g�_�������$�3o6��~���{�rZ�X6y���8��h\rv��:\"SÈqX#�<)@�[.��$MzG���-��*[�]�8<=�W�4d�K��)@�PǬw�/^TҖ�,A��ר�ԊF:�t{l������n�`�\Z0m�bt�G��;8�Q�tO�s=:��.gx�����h=���l9��#C\Zt�\r�#�_�8p���e�Ħݟ����{�������� ��z�n�UO�?0[���\0��x��pX�Ho��\Z[6DXG�!�e#\Zg��$�R�o�N,	:S7pn;��A�x�Kc��6�& ��n��?}Ֆ�Ծ\'}��;�0�@o���\0�lb*�Uru�!����~%/�y|8���w��a.}4���b�nȱ�a���6|��v�*]	a<Ve�1B:9KOoM�_��pz�d���e�J@����H\'�,�q�(<H�q�Q��OC�rB����,��7,���T�<�l��3-FP�P������W0^U9D����\'pZ�:����ʶV�����U�:2�b�|�_���²D�gw�i���ƪ��p�`��D��5�c1�(���4���oI����߸�] ֢5JV�J8��M���W�1l��Yt2ě��t?�n�Ł7I�MI�\'ӿ�ϣ,�');
/*!40000 ALTER TABLE `cache_rootline` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cache_rootline_tags`
--

DROP TABLE IF EXISTS `cache_rootline_tags`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_rootline_tags` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `identifier` varchar(250) NOT NULL DEFAULT '',
  `tag` varchar(250) NOT NULL DEFAULT '',
  PRIMARY KEY (`id`),
  KEY `cache_id` (`identifier`(191)),
  KEY `cache_tag` (`tag`(191))
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_rootline_tags`
--

LOCK TABLES `cache_rootline_tags` WRITE;
/*!40000 ALTER TABLE `cache_rootline_tags` DISABLE KEYS */;
INSERT INTO `cache_rootline_tags` VALUES
(1,'1__0_0_1_1','pageId_1'),
(2,'1__0_0_0_0','pageId_1');
/*!40000 ALTER TABLE `cache_rootline_tags` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_groups`
--

DROP TABLE IF EXISTS `fe_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_groups` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(50) NOT NULL DEFAULT '',
  `subgroup` varchar(255) DEFAULT '',
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_groups`
--

LOCK TABLES `fe_groups` WRITE;
/*!40000 ALTER TABLE `fe_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_sessions`
--

DROP TABLE IF EXISTS `fe_sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_sessions` (
  `ses_id` varchar(190) NOT NULL DEFAULT '',
  `ses_iplock` varchar(39) NOT NULL DEFAULT '',
  `ses_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `ses_data` mediumblob DEFAULT NULL,
  `ses_permanent` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`ses_id`),
  KEY `ses_tstamp` (`ses_tstamp`,`ses_userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_sessions`
--

LOCK TABLES `fe_sessions` WRITE;
/*!40000 ALTER TABLE `fe_sessions` DISABLE KEYS */;
INSERT INTO `fe_sessions` VALUES
('04ee986b8f61deaab8546c43c5a96cb7bbd6923f3f8f93cb00d3efe43909a75d','[DISABLED]',0,1777631651,'a:1:{s:33:\"tx_form_honeypot_name_ert-2page-1\";s:21:\"oWAt9vBzUagXRHOLIpebD\";}',0),
('1f11636db77bb6f1418b5629d655402a72fabfa0e85ebdeeadca64a54dc1ea0c','[DISABLED]',0,1779125125,'a:1:{s:33:\"tx_form_honeypot_name_ert-2page-1\";s:13:\"XSkzOveBIExwJ\";}',0),
('2db3523468f5171fba43625e783c1927e703693ec8f8425d9d81efc8466af1cf','[DISABLED]',0,1776096636,'a:1:{s:33:\"tx_form_honeypot_name_ert-2page-1\";s:26:\"TMGUOWFPfqXhEVc9sRZr7LoaH6\";}',0),
('5de91ad908157aeba8940e1890ac720938694024430830179a7b253ec229b624','[DISABLED]',0,1778572820,'a:1:{s:33:\"tx_form_honeypot_name_ert-2page-1\";s:23:\"fyxJGVdhj7X0DQWRikZ9FbP\";}',0),
('8bd9c845ab6f76395c3b8444dd8fb1772e04c682e6cce76ef229c990a3fcd447','[DISABLED]',0,1776096674,'a:1:{s:33:\"tx_form_honeypot_name_ert-2page-1\";s:16:\"XPO9xQuJB60pAFvs\";}',0),
('deae79af95e50da88c38353b9d4bc83db8b3339b42824b8a534b3f88e085564f','[DISABLED]',0,1777627672,'a:1:{s:33:\"tx_form_honeypot_name_ert-2page-1\";s:9:\"EbuyvtXcd\";}',0);
/*!40000 ALTER TABLE `fe_sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fe_users`
--

DROP TABLE IF EXISTS `fe_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `fe_users` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disable` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_extbase_type` varchar(255) NOT NULL DEFAULT '0',
  `uc` blob DEFAULT NULL,
  `is_online` int(10) unsigned NOT NULL DEFAULT 0,
  `mfa` mediumblob DEFAULT NULL,
  `felogin_forgotHash` varchar(160) DEFAULT '',
  `username` varchar(255) NOT NULL DEFAULT '',
  `password` varchar(255) NOT NULL DEFAULT '',
  `usergroup` varchar(512) DEFAULT '',
  `name` varchar(160) NOT NULL DEFAULT '',
  `first_name` varchar(50) NOT NULL DEFAULT '',
  `middle_name` varchar(50) NOT NULL DEFAULT '',
  `last_name` varchar(50) NOT NULL DEFAULT '',
  `address` longtext DEFAULT NULL,
  `telephone` varchar(30) NOT NULL DEFAULT '',
  `fax` varchar(30) NOT NULL DEFAULT '',
  `email` varchar(255) NOT NULL DEFAULT '',
  `title` varchar(40) NOT NULL DEFAULT '',
  `zip` varchar(10) NOT NULL DEFAULT '',
  `city` varchar(50) NOT NULL DEFAULT '',
  `country` varchar(40) NOT NULL DEFAULT '',
  `www` varchar(80) NOT NULL DEFAULT '',
  `company` varchar(80) NOT NULL DEFAULT '',
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `lastlogin` bigint(20) NOT NULL DEFAULT 0,
  `felogin_redirectPid` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`username`(100)),
  KEY `username` (`username`(100)),
  KEY `is_online` (`is_online`),
  KEY `felogin_forgotHash` (`felogin_forgotHash`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fe_users`
--

LOCK TABLES `fe_users` WRITE;
/*!40000 ALTER TABLE `fe_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `fe_users` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `form_definition`
--

DROP TABLE IF EXISTS `form_definition`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `form_definition` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `identifier` varchar(255) NOT NULL DEFAULT '',
  `configuration` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`configuration`)),
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `form_definition`
--

LOCK TABLES `form_definition` WRITE;
/*!40000 ALTER TABLE `form_definition` DISABLE KEYS */;
/*!40000 ALTER TABLE `form_definition` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `pages` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `perms_userid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_groupid` int(10) unsigned NOT NULL DEFAULT 0,
  `perms_user` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_group` smallint(5) unsigned NOT NULL DEFAULT 0,
  `perms_everybody` smallint(5) unsigned NOT NULL DEFAULT 0,
  `SYS_LASTCHANGED` int(10) unsigned NOT NULL DEFAULT 0,
  `shortcut` int(10) unsigned NOT NULL DEFAULT 0,
  `content_from_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `mount_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `sitemap_priority` decimal(2,1) NOT NULL DEFAULT 0.5,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `doktype` int(10) unsigned NOT NULL DEFAULT 1,
  `title` varchar(255) NOT NULL DEFAULT '',
  `slug` text DEFAULT NULL,
  `TSconfig` longtext DEFAULT NULL,
  `php_tree_stop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `extendToSubpages` smallint(5) unsigned NOT NULL DEFAULT 0,
  `nav_title` varchar(255) NOT NULL DEFAULT '',
  `nav_hide` smallint(5) unsigned NOT NULL DEFAULT 0,
  `subtitle` varchar(255) NOT NULL DEFAULT '',
  `target` varchar(80) NOT NULL DEFAULT '',
  `link` text NOT NULL DEFAULT '',
  `lastUpdated` bigint(20) NOT NULL DEFAULT 0,
  `newUntil` bigint(20) NOT NULL DEFAULT 0,
  `cache_timeout` int(10) unsigned NOT NULL DEFAULT 0,
  `cache_tags` varchar(255) NOT NULL DEFAULT '',
  `no_search` smallint(5) unsigned NOT NULL DEFAULT 0,
  `shortcut_mode` int(10) unsigned NOT NULL DEFAULT 0,
  `keywords` longtext DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `abstract` longtext DEFAULT NULL,
  `author` varchar(255) NOT NULL DEFAULT '',
  `author_email` varchar(255) NOT NULL DEFAULT '',
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `is_siteroot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `mount_pid_ol` smallint(6) NOT NULL DEFAULT 0,
  `module` varchar(255) NOT NULL DEFAULT '',
  `l18n_cfg` smallint(5) unsigned NOT NULL DEFAULT 0,
  `backend_layout` varchar(64) NOT NULL DEFAULT '',
  `backend_layout_next_level` varchar(64) NOT NULL DEFAULT '',
  `tsconfig_includes` varchar(255) DEFAULT '',
  `seo_title` varchar(255) NOT NULL DEFAULT '',
  `no_index` smallint(5) unsigned NOT NULL DEFAULT 0,
  `no_follow` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sitemap_changefreq` varchar(10) NOT NULL DEFAULT '',
  `canonical_link` text NOT NULL DEFAULT '',
  `og_title` varchar(255) NOT NULL DEFAULT '',
  `og_description` longtext DEFAULT NULL,
  `og_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_title` varchar(255) NOT NULL DEFAULT '',
  `twitter_description` longtext DEFAULT NULL,
  `twitter_image` int(10) unsigned NOT NULL DEFAULT 0,
  `twitter_card` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `determineSiteRoot` (`is_siteroot`),
  KEY `slug` (`slug`(127)),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`),
  KEY `contentFromPid` (`content_from_pid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES
(1,0,1776096069,1776096069,0,0,0,0,'0',512,NULL,0,0,0,0,NULL,NULL,0,0,0,0,1,1,31,31,1,1777630715,0,0,0,0.5,0,1,'Home','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,1,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,''),
(2,0,1776096641,1776096260,1,0,0,0,'0',256,NULL,0,0,0,0,NULL,'{\"hidden\":\"\"}',0,0,0,0,1,0,31,27,0,0,0,0,0,0.5,0,1,'hh','/',NULL,0,0,0,0,'',0,'','','',0,0,0,'',0,0,NULL,NULL,NULL,'','',0,0,0,'',0,'','','','',0,0,'','','',NULL,0,'',NULL,0,'');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts`
--

DROP TABLE IF EXISTS `sys_be_shortcuts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `route` varchar(255) NOT NULL DEFAULT '',
  `arguments` text DEFAULT NULL,
  `description` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `sc_group` smallint(6) NOT NULL DEFAULT 0,
  `group_uuid` char(36) DEFAULT NULL COMMENT '(DC2Type:guid)',
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts`
--

LOCK TABLES `sys_be_shortcuts` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_be_shortcuts_group`
--

DROP TABLE IF EXISTS `sys_be_shortcuts_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_be_shortcuts_group` (
  `uuid` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `label` varchar(255) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uuid`),
  KEY `user_groups` (`userid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_be_shortcuts_group`
--

LOCK TABLES `sys_be_shortcuts_group` WRITE;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_be_shortcuts_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category`
--

DROP TABLE IF EXISTS `sys_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `items` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `parent` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `category_parent` (`parent`),
  KEY `category_list` (`pid`,`deleted`,`sys_language_uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category`
--

LOCK TABLES `sys_category` WRITE;
/*!40000 ALTER TABLE `sys_category` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_category_record_mm`
--

DROP TABLE IF EXISTS `sys_category_record_mm`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_category_record_mm` (
  `uid_local` int(10) unsigned NOT NULL DEFAULT 0,
  `uid_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting_foreign` int(10) unsigned NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid_local`,`uid_foreign`,`tablenames`,`fieldname`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_category_record_mm`
--

LOCK TABLES `sys_category_record_mm` WRITE;
/*!40000 ALTER TABLE `sys_category_record_mm` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_category_record_mm` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_csp_resolution`
--

DROP TABLE IF EXISTS `sys_csp_resolution`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_csp_resolution` (
  `summary` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `scope` varchar(264) NOT NULL,
  `mutation_identifier` text DEFAULT NULL,
  `mutation_collection` mediumtext DEFAULT NULL,
  `meta` mediumtext DEFAULT NULL,
  PRIMARY KEY (`summary`),
  KEY `created` (`created`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_csp_resolution`
--

LOCK TABLES `sys_csp_resolution` WRITE;
/*!40000 ALTER TABLE `sys_csp_resolution` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_csp_resolution` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file`
--

DROP TABLE IF EXISTS `sys_file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `last_indexed` int(11) NOT NULL DEFAULT 0,
  `identifier` text DEFAULT NULL,
  `identifier_hash` varchar(40) NOT NULL DEFAULT '',
  `folder_hash` varchar(40) NOT NULL DEFAULT '',
  `extension` varchar(255) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `sha1` varchar(40) NOT NULL DEFAULT '',
  `creation_date` int(11) NOT NULL DEFAULT 0,
  `modification_date` int(11) NOT NULL DEFAULT 0,
  `size` bigint(20) NOT NULL DEFAULT 0,
  `storage` int(10) unsigned NOT NULL DEFAULT 0,
  `type` int(10) unsigned NOT NULL DEFAULT 0,
  `mime_type` varchar(255) NOT NULL DEFAULT '',
  `missing` smallint(5) unsigned NOT NULL DEFAULT 0,
  `metadata` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `sel01` (`storage`,`identifier_hash`),
  KEY `folder` (`storage`,`folder_hash`),
  KEY `tstamp` (`tstamp`),
  KEY `lastindex` (`last_indexed`),
  KEY `sha1` (`sha1`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file`
--

LOCK TABLES `sys_file` WRITE;
/*!40000 ALTER TABLE `sys_file` DISABLE KEYS */;
INSERT INTO `sys_file` VALUES
(1,0,1779055311,1779055311,'/form_definitions/ert.form.yaml','ddf9871744fdceabb77c8c1fcb20987641e490db','c62e3e70a526a59f0f0b7687864947eab72d7d3f','yaml','ert.form.yaml','702ef203b089ec23f674bc6d2304f603d5905dff',1779055311,1779055311,2923,1,5,'application/yaml',0,0),
(2,0,1778571176,1778571176,'/_temp_/index.html','1cd5eec12b9b11599c0b4c6b2d43342c4fb53a7b','0258f8a5f703dd44c350fbfcddeecb1634d46ad4','html','index.html','86f257eae12059ed5daf12ce6e5508f5f893012a',1776096003,1776096003,116,1,1,'text/html',0,0),
(3,0,1778571177,1778571177,'/user_upload/index.html','c25533f303185517ca3e1e24b215d53aa74076d2','19669f1e02c2f16705ec7587044c66443be70725','html','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',1776096003,1776096003,0,1,5,'application/x-empty',0,0),
(4,0,1778571276,1778571276,'/user_upload/_temp_/index.html','a3ef597b554ed2a28c720b3e90e51edc9ec642b1','4e0743c93934dd9a02564d8e654d714bd2dc3d20','html','index.html','da39a3ee5e6b4b0d3255bfef95601890afd80709',1776096003,1776096003,0,1,5,'application/x-empty',0,0),
(5,0,1778571279,1778571279,'/user_upload/_temp_/importexport/index.html','68614dc2826769e93d8a8ead62af30ac99aaa83a','0795cf796b4fc959be0ec00b183c0f47609dd9a5','html','index.html','86f257eae12059ed5daf12ce6e5508f5f893012a',1776096003,1776096003,116,1,1,'text/html',0,0),
(6,0,1778571967,1778571967,'/options_providers/countries-dach.json','71c7c8d30a52542cd4b7660d8d54759f684145de','c32bee4a23568a09fea311dd855458c8c4331e53','json','countries-dach.json','cfb9b731a79ea71557d1a4a8b923b2347f6c68a2',1778571387,1778571387,130,1,5,'application/json',0,0),
(7,0,1778571967,1778571967,'/options_providers/countries-europe.csv','b6c75f9d740ea6e979d8ddf3c46f66bef2502531','c32bee4a23568a09fea311dd855458c8c4331e53','csv','countries-europe.csv','0214e9f182780548f06d5cd7c942708581eb225b',1778571377,1778571377,342,1,1,'text/csv',0,0),
(8,0,1778571967,1778571967,'/options_providers/countries-worldwide.json','c19cb6adf5707167d986108589b330d5f0787282','c32bee4a23568a09fea311dd855458c8c4331e53','json','countries-worldwide.json','a4dea30cac926daaea73b62c6caa5b896c26bc43',1778571383,1778571383,660,1,5,'application/json',0,0),
(9,0,1778571967,1778571967,'/options_providers/universities-germany.csv','1dcb8fb9006151d953f1134c06ba7d269a22392b','c32bee4a23568a09fea311dd855458c8c4331e53','csv','universities-germany.csv','440de17444c6bcb85f4fcaee6d97a170ad83521e',1778571393,1778571393,791,1,1,'text/csv',0,0);
/*!40000 ALTER TABLE `sys_file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_collection`
--

DROP TABLE IF EXISTS `sys_file_collection`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_collection` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `type` varchar(30) NOT NULL DEFAULT 'static',
  `files` int(10) unsigned NOT NULL DEFAULT 0,
  `folder_identifier` longtext DEFAULT NULL,
  `recursive` smallint(5) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_collection`
--

LOCK TABLES `sys_file_collection` WRITE;
/*!40000 ALTER TABLE `sys_file_collection` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_collection` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_metadata`
--

DROP TABLE IF EXISTS `sys_file_metadata`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_metadata` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `file` int(10) unsigned NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `width` int(11) NOT NULL DEFAULT 0,
  `height` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `file` (`file`),
  KEY `parent` (`pid`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_metadata`
--

LOCK TABLES `sys_file_metadata` WRITE;
/*!40000 ALTER TABLE `sys_file_metadata` DISABLE KEYS */;
INSERT INTO `sys_file_metadata` VALUES
(1,0,1776096557,1776096557,0,0,NULL,'',0,0,0,0,NULL,NULL,0,1,NULL,0,0),
(2,0,1778571176,1778571176,0,0,NULL,'',0,0,0,0,NULL,NULL,0,2,NULL,0,0),
(3,0,1778571177,1778571177,0,0,NULL,'',0,0,0,0,NULL,NULL,0,3,NULL,0,0),
(4,0,1778571276,1778571276,0,0,NULL,'',0,0,0,0,NULL,NULL,0,4,NULL,0,0),
(5,0,1778571279,1778571279,0,0,NULL,'',0,0,0,0,NULL,NULL,0,5,NULL,0,0),
(6,0,1778571967,1778571967,0,0,NULL,'',0,0,0,0,NULL,NULL,0,6,NULL,0,0),
(7,0,1778571967,1778571967,0,0,NULL,'',0,0,0,0,NULL,NULL,0,7,NULL,0,0),
(8,0,1778571967,1778571967,0,0,NULL,'',0,0,0,0,NULL,NULL,0,8,NULL,0,0),
(9,0,1778571967,1778571967,0,0,NULL,'',0,0,0,0,NULL,NULL,0,9,NULL,0,0);
/*!40000 ALTER TABLE `sys_file_metadata` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_processedfile`
--

DROP TABLE IF EXISTS `sys_file_processedfile`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_processedfile` (
  `uid` int(11) NOT NULL AUTO_INCREMENT,
  `tstamp` int(11) NOT NULL DEFAULT 0,
  `crdate` int(11) NOT NULL DEFAULT 0,
  `storage` int(11) NOT NULL DEFAULT 0,
  `original` int(11) NOT NULL DEFAULT 0,
  `identifier` varchar(512) NOT NULL DEFAULT '',
  `name` tinytext DEFAULT NULL,
  `processing_url` text DEFAULT NULL,
  `configuration` blob DEFAULT NULL,
  `configurationsha1` varchar(40) NOT NULL DEFAULT '',
  `originalfilesha1` varchar(40) NOT NULL DEFAULT '',
  `task_type` varchar(200) NOT NULL DEFAULT '',
  `checksum` varchar(32) NOT NULL DEFAULT '',
  `width` int(11) DEFAULT 0,
  `height` int(11) DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `combined_1` (`original`,`task_type`(100),`configurationsha1`),
  KEY `identifier` (`storage`,`identifier`(180))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_processedfile`
--

LOCK TABLES `sys_file_processedfile` WRITE;
/*!40000 ALTER TABLE `sys_file_processedfile` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_processedfile` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_reference`
--

DROP TABLE IF EXISTS `sys_file_reference`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_reference` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l10n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l10n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `uid_local` int(11) NOT NULL DEFAULT 0,
  `title` tinytext DEFAULT NULL,
  `alternative` text DEFAULT NULL,
  `uid_foreign` int(11) NOT NULL DEFAULT 0,
  `tablenames` varchar(64) NOT NULL DEFAULT '',
  `fieldname` varchar(64) NOT NULL DEFAULT '',
  `sorting_foreign` int(11) NOT NULL DEFAULT 0,
  `link` text NOT NULL DEFAULT '',
  `description` longtext DEFAULT NULL,
  `crop` longtext DEFAULT NULL,
  `autoplay` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `tablenames_fieldname` (`tablenames`(32),`fieldname`(12)),
  KEY `deleted` (`deleted`),
  KEY `uid_local` (`uid_local`),
  KEY `uid_foreign` (`uid_foreign`),
  KEY `combined_1` (`l10n_parent`,`t3ver_oid`,`t3ver_wsid`,`t3ver_state`,`deleted`),
  KEY `parent` (`pid`,`deleted`,`hidden`),
  KEY `language_identifier` (`l10n_parent`,`sys_language_uid`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_reference`
--

LOCK TABLES `sys_file_reference` WRITE;
/*!40000 ALTER TABLE `sys_file_reference` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_file_reference` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_file_storage`
--

DROP TABLE IF EXISTS `sys_file_storage`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_file_storage` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `is_public` smallint(6) NOT NULL DEFAULT 0,
  `processingfolder` tinytext DEFAULT NULL,
  `name` varchar(255) NOT NULL DEFAULT '',
  `is_browsable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_default` smallint(5) unsigned NOT NULL DEFAULT 0,
  `is_writable` smallint(5) unsigned NOT NULL DEFAULT 1,
  `is_online` smallint(5) unsigned NOT NULL DEFAULT 1,
  `auto_extract_metadata` smallint(5) unsigned NOT NULL DEFAULT 1,
  `driver` varchar(255) NOT NULL DEFAULT 'Local',
  `configuration` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_file_storage`
--

LOCK TABLES `sys_file_storage` WRITE;
/*!40000 ALTER TABLE `sys_file_storage` DISABLE KEYS */;
INSERT INTO `sys_file_storage` VALUES
(1,0,1776096227,1776096227,0,'This is the local fileadmin/ directory. This storage mount has been created automatically by TYPO3.',1,NULL,'fileadmin',1,1,1,1,1,'Local','<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"basePath\">\n                    <value index=\"vDEF\">fileadmin/</value>\n                </field>\n                <field index=\"pathType\">\n                    <value index=\"vDEF\">relative</value>\n                </field>\n                <field index=\"caseSensitive\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>');
/*!40000 ALTER TABLE `sys_file_storage` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_filemounts`
--

DROP TABLE IF EXISTS `sys_filemounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_filemounts` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `title` varchar(255) NOT NULL DEFAULT '',
  `identifier` longtext DEFAULT NULL,
  `read_only` smallint(5) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_filemounts`
--

LOCK TABLES `sys_filemounts` WRITE;
/*!40000 ALTER TABLE `sys_filemounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_filemounts` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_history`
--

DROP TABLE IF EXISTS `sys_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_history` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `actiontype` smallint(6) NOT NULL DEFAULT 0,
  `usertype` varchar(2) NOT NULL DEFAULT 'BE',
  `userid` int(10) unsigned DEFAULT NULL,
  `originaluserid` int(10) unsigned DEFAULT NULL,
  `recuid` int(11) NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `history_data` mediumtext DEFAULT NULL,
  `workspace` int(11) DEFAULT 0,
  `correlation_id` varchar(255) NOT NULL DEFAULT '',
  PRIMARY KEY (`uid`),
  KEY `recordident_1` (`tablename`(100),`recuid`),
  KEY `recordident_2` (`tablename`(100),`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_history`
--

LOCK TABLES `sys_history` WRITE;
/*!40000 ALTER TABLE `sys_history` DISABLE KEYS */;
INSERT INTO `sys_history` VALUES
(1,1776096260,1,'BE',1,0,2,'pages','{\"doktype\":\"1\",\"slug\":\"\\/\",\"sitemap_priority\":\"0.5\",\"twitter_card\":\"\",\"lastUpdated\":0,\"layout\":\"0\",\"newUntil\":0,\"content_from_pid\":0,\"cache_timeout\":\"0\",\"module\":\"\",\"hidden\":\"1\",\"starttime\":0,\"endtime\":0,\"categories\":\"0\",\"pid\":0,\"sorting\":256,\"perms_userid\":1,\"perms_groupid\":0,\"perms_user\":31,\"perms_group\":27,\"perms_everybody\":0,\"title\":\"hh\",\"nav_hide\":\"0\",\"l10n_diffsource\":\"{\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\"}\",\"crdate\":1776096260,\"t3ver_stage\":0,\"tstamp\":1776096260,\"uid\":2}',0,'0400$f08e22ef48f1107103354664613b78a6:f11830df10b4b0bca2db34810c2241b3'),
(2,1776096260,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"l10n_diffsource\":\"{\\\"cache_timeout\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"content_from_pid\\\":\\\"\\\",\\\"doktype\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"lastUpdated\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"module\\\":\\\"\\\",\\\"nav_hide\\\":\\\"\\\",\\\"newUntil\\\":\\\"\\\",\\\"sitemap_priority\\\":\\\"\\\",\\\"slug\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"title\\\":\\\"\\\",\\\"twitter_card\\\":\\\"\\\"}\"},\"newRecord\":{\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"}}',0,'0400$7050b90fe66f19e62182ec64ef78b36a:f11830df10b4b0bca2db34810c2241b3'),
(3,1776096265,2,'BE',1,0,2,'pages','{\"oldRecord\":{\"hidden\":1,\"l10n_diffsource\":\"{\\\"slug\\\":\\\"\\\"}\"},\"newRecord\":{\"hidden\":\"0\",\"l10n_diffsource\":\"{\\\"hidden\\\":\\\"\\\"}\"}}',0,'0400$8b86d561fa3021c0a48975e9adc67a5c:f11830df10b4b0bca2db34810c2241b3'),
(4,1776096632,1,'BE',1,0,2,'tt_content','{\"CType\":\"form_formframework\",\"colPos\":\"0\",\"header_layout\":\"0\",\"tx_themecamino_header_style\":\"0\",\"header_position\":\"\",\"date\":0,\"layout\":\"0\",\"frame_class\":\"default\",\"space_before_class\":\"\",\"space_after_class\":\"\",\"sectionIndex\":\"1\",\"categories\":\"0\",\"l18n_parent\":0,\"hidden\":\"0\",\"starttime\":0,\"endtime\":0,\"pid\":1,\"sorting\":256,\"sys_language_uid\":0,\"header\":\"\",\"header_link\":\"\",\"subheader\":\"\",\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.persistenceIdentifier\\\">\\n                    <value index=\\\"vDEF\\\">1:\\/form_definitions\\/ert.form.yaml<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"linkToTop\":\"0\",\"editlock\":\"0\",\"rowDescription\":\"\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\"}\",\"crdate\":1776096632,\"t3ver_stage\":0,\"tstamp\":1776096632,\"uid\":2}',0,'0400$74f63b61d6f072f22d1fca3fb3323d12:01dbc21fdb1263685b9147b3b1596ea8'),
(5,1776096633,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.persistenceIdentifier\\\">\\n                    <value index=\\\"vDEF\\\">1:\\/form_definitions\\/ert.form.yaml<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"categories\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\",\\\"tx_themecamino_header_style\\\":\\\"\\\"}\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.persistenceIdentifier\\\">\\n                    <value index=\\\"vDEF\\\">1:\\/form_definitions\\/ert.form.yaml<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.overrideFinishers\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"l18n_diffsource\":\"{\\\"CType\\\":\\\"\\\",\\\"colPos\\\":\\\"\\\",\\\"date\\\":\\\"\\\",\\\"editlock\\\":\\\"\\\",\\\"endtime\\\":\\\"\\\",\\\"frame_class\\\":\\\"\\\",\\\"header\\\":\\\"\\\",\\\"header_layout\\\":\\\"\\\",\\\"header_link\\\":\\\"\\\",\\\"header_position\\\":\\\"\\\",\\\"hidden\\\":\\\"\\\",\\\"layout\\\":\\\"\\\",\\\"linkToTop\\\":\\\"\\\",\\\"pi_flexform\\\":\\\"\\\",\\\"rowDescription\\\":\\\"\\\",\\\"sectionIndex\\\":\\\"\\\",\\\"space_after_class\\\":\\\"\\\",\\\"space_before_class\\\":\\\"\\\",\\\"starttime\\\":\\\"\\\",\\\"subheader\\\":\\\"\\\"}\"}}',0,'0400$5a3d2498fc3263912b9575b5bc501d78:01dbc21fdb1263685b9147b3b1596ea8'),
(6,1776096641,4,'BE',1,0,2,'pages',NULL,0,'0400$ba2a88ab29e7d459ab5e0e24c7808442:f11830df10b4b0bca2db34810c2241b3'),
(7,1777630715,2,'BE',1,0,2,'tt_content','{\"oldRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.persistenceIdentifier\\\">\\n                    <value index=\\\"vDEF\\\">1:\\/form_definitions\\/ert.form.yaml<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.overrideFinishers\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"},\"newRecord\":{\"pi_flexform\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"settings.persistenceIdentifier\\\">\\n                    <value index=\\\"vDEF\\\">1:\\/form_definitions\\/ert.form.yaml<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.overrideFinishers\\\">\\n                    <value index=\\\"vDEF\\\">0<\\/value>\\n                <\\/field>\\n                <field index=\\\"settings.useAjax\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\"}}',0,'0400$95200154306a36184fe62faaa0169699:01dbc21fdb1263685b9147b3b1596ea8'),
(8,1778571261,1,'BE',1,0,2,'sys_file_storage','{\"driver\":\"Local\",\"is_default\":\"0\",\"auto_extract_metadata\":\"1\",\"is_browsable\":\"1\",\"is_public\":\"1\",\"is_writable\":\"1\",\"is_online\":\"1\",\"pid\":0,\"name\":\"options_providers\",\"configuration\":\"<?xml version=\\\"1.0\\\" encoding=\\\"utf-8\\\" standalone=\\\"yes\\\" ?>\\n<T3FlexForms>\\n    <data>\\n        <sheet index=\\\"sDEF\\\">\\n            <language index=\\\"lDEF\\\">\\n                <field index=\\\"basePath\\\">\\n                    <value index=\\\"vDEF\\\">options_providers<\\/value>\\n                <\\/field>\\n                <field index=\\\"pathType\\\">\\n                    <value index=\\\"vDEF\\\">relative<\\/value>\\n                <\\/field>\\n                <field index=\\\"baseUri\\\">\\n                    <value index=\\\"vDEF\\\"><\\/value>\\n                <\\/field>\\n                <field index=\\\"caseSensitive\\\">\\n                    <value index=\\\"vDEF\\\">1<\\/value>\\n                <\\/field>\\n            <\\/language>\\n        <\\/sheet>\\n    <\\/data>\\n<\\/T3FlexForms>\",\"processingfolder\":\"\",\"description\":\"\",\"crdate\":1778571261,\"tstamp\":1778571261,\"uid\":2}',0,'0400$d06edfcb1ce028c0741463d59ffb90f8:5eff126078f90e44cb448b9015a89655');
/*!40000 ALTER TABLE `sys_history` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_http_report`
--

DROP TABLE IF EXISTS `sys_http_report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_http_report` (
  `uuid` varchar(36) NOT NULL,
  `status` smallint(5) unsigned NOT NULL DEFAULT 0,
  `created` int(10) unsigned NOT NULL,
  `changed` int(10) unsigned NOT NULL,
  `type` varchar(32) NOT NULL,
  `scope` varchar(100) NOT NULL,
  `request_time` bigint(20) unsigned NOT NULL,
  `meta` mediumtext DEFAULT NULL,
  `details` mediumtext DEFAULT NULL,
  `summary` varchar(40) NOT NULL,
  PRIMARY KEY (`uuid`),
  KEY `type_scope` (`type`,`scope`),
  KEY `created` (`created`),
  KEY `changed` (`changed`),
  KEY `request_time` (`request_time`),
  KEY `summary_created` (`summary`,`created`),
  KEY `all_conditions` (`type`,`status`,`scope`,`summary`,`request_time`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_http_report`
--

LOCK TABLES `sys_http_report` WRITE;
/*!40000 ALTER TABLE `sys_http_report` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_http_report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_lockedrecords`
--

DROP TABLE IF EXISTS `sys_lockedrecords`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_lockedrecords` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `record_table` varchar(255) NOT NULL DEFAULT '',
  `record_uid` int(11) NOT NULL DEFAULT 0,
  `record_pid` int(11) NOT NULL DEFAULT 0,
  `username` varchar(50) NOT NULL DEFAULT '',
  `feuserid` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`tstamp`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_lockedrecords`
--

LOCK TABLES `sys_lockedrecords` WRITE;
/*!40000 ALTER TABLE `sys_lockedrecords` DISABLE KEYS */;
INSERT INTO `sys_lockedrecords` VALUES
(10,1,1779086339,'sys_file_metadata',7,0,'mir',0);
/*!40000 ALTER TABLE `sys_lockedrecords` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_log`
--

DROP TABLE IF EXISTS `sys_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_log` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `userid` int(10) unsigned NOT NULL DEFAULT 0,
  `action` smallint(5) unsigned NOT NULL DEFAULT 0,
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `tablename` varchar(255) NOT NULL DEFAULT '',
  `recpid` int(11) NOT NULL DEFAULT 0,
  `error` smallint(5) unsigned NOT NULL DEFAULT 0,
  `details` text DEFAULT NULL,
  `type` smallint(5) unsigned NOT NULL DEFAULT 0,
  `channel` varchar(20) NOT NULL DEFAULT 'default',
  `IP` varchar(39) NOT NULL DEFAULT '',
  `log_data` text DEFAULT NULL,
  `event_pid` int(11) NOT NULL DEFAULT -1,
  `workspace` int(11) NOT NULL DEFAULT 0,
  `request_id` varchar(13) NOT NULL DEFAULT '',
  `time_micro` double NOT NULL DEFAULT 0,
  `component` varchar(255) NOT NULL DEFAULT '',
  `level` varchar(10) NOT NULL DEFAULT 'info',
  `message` text DEFAULT NULL,
  `data` text DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `event` (`userid`,`event_pid`),
  KEY `recuidIdx` (`recuid`),
  KEY `user_auth` (`type`,`action`,`tstamp`),
  KEY `request` (`request_id`),
  KEY `combined_1` (`tstamp`,`type`,`userid`),
  KEY `errorcount` (`tstamp`,`error`),
  KEY `index_channel` (`channel`),
  KEY `index_level` (`level`)
) ENGINE=InnoDB AUTO_INCREMENT=65 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_log`
--

LOCK TABLES `sys_log` WRITE;
/*!40000 ALTER TABLE `sys_log` DISABLE KEYS */;
INSERT INTO `sys_log` VALUES
(1,1776096186,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(2,1776096194,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user','','[\"mir\"]',-1,-99,'',0,'','info',NULL,NULL),
(3,1776096200,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"mir\"]',-1,-99,'',0,'','info',NULL,NULL),
(4,1776096260,1,1,2,'pages',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(5,1776096260,1,1,0,'site',0,0,'Site configuration \'%s\' was automatically created for new root page (%s).',6,'site','172.18.0.5','[\"autogenerated-2-c81e728d9d4c2f636f067f89cc14862c\",2]',-1,0,'',0,'','info',NULL,NULL),
(6,1776096260,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"2\"}',0,0,'',0,'','info',NULL,NULL),
(7,1776096265,1,2,2,'pages',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"pages\",\"uid\":2,\"history\":\"3\"}',0,0,'',0,'','info',NULL,NULL),
(8,1776096269,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: No site configuration or TypoScript template record found! | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 56. Requested URL: https://t3-forms.ddev.site/autogenerated-2/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(9,1776096388,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"mir\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(10,1776096430,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.18.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(11,1776096462,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"mir\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(12,1776096480,1,4,0,'site',0,0,'Site configuration \'%s\' was deleted.',6,'site','172.18.0.5','[\"autogenerated-2-c81e728d9d4c2f636f067f89cc14862c\"]',-1,0,'',0,'','info',NULL,NULL),
(13,1776096484,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1146: An exception occurred while executing a query: Table \'db.tx_themecamino_list_item\' doesn\'t exist | Doctrine\\DBAL\\Exception\\TableNotFoundException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 51. Requested URL: https://t3-forms.ddev.site/typo3/ajax/record/process?token=--AnonymizedToken--cdb049b17c80389ae9e8f9fc&cmd%%5Bpages%%5D%%5B2%%5D%%5Bdelete%%5D=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(14,1776096496,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1146: An exception occurred while executing a query: Table \'db.tx_themecamino_list_item\' doesn\'t exist | Doctrine\\DBAL\\Exception\\TableNotFoundException thrown in file /var/www/html/vendor/doctrine/dbal/src/Driver/API/MySQL/ExceptionConverter.php in line 51. Requested URL: https://t3-forms.ddev.site/typo3/ajax/record/process?token=--AnonymizedToken--cdb049b17c80389ae9e8f9fc&cmd%%5Bpages%%5D%%5B2%%5D%%5Bdelete%%5D=1',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(15,1776096504,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"mir\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(16,1776096524,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.18.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(17,1776096530,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"mir\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(18,1776096571,1,1,0,'tt_content',0,2,'SQL error: \"{reason}\" ({table}:{uid})',1,'content','172.18.0.5','{\"reason\":\"An exception occurred while executing a query: Unknown column \'tx_themecamino_header_style\' in \'INSERT INTO\'\",\"table\":\"tt_content\",\"uid\":\"NEW69dd153657d23616764404\"}',-1,0,'',0,'','info',NULL,NULL),
(19,1776096583,1,1,0,'tt_content',0,2,'SQL error: \"{reason}\" ({table}:{uid})',1,'content','172.18.0.5','{\"reason\":\"An exception occurred while executing a query: Unknown column \'tx_themecamino_header_style\' in \'INSERT INTO\'\",\"table\":\"tt_content\",\"uid\":\"NEW69dd153b215d9267457883\"}',-1,0,'',0,'','info',NULL,NULL),
(20,1776096632,1,1,2,'tt_content',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":2,\"pid\":1}',1,0,'',0,'','info',NULL,NULL),
(21,1776096633,1,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":2,\"history\":\"5\"}',1,0,'',0,'','info',NULL,NULL),
(22,1776096641,1,3,2,'pages',0,0,'Record pages:{uid} was deleted',1,'content','172.18.0.5','{\"uid\":2}',0,0,'',0,'','info',NULL,NULL),
(23,1776096665,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.18.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(24,1776096672,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"mir\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(25,1777629779,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: Site main depends on unavailable sets: t13-forms/sitepackage | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 56. Requested URL: https://t3-forms.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(26,1777629779,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: Site main depends on unavailable sets: t13-forms/sitepackage | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 56. Requested URL: https://t3-forms.ddev.site/favicon.ico',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(27,1777629827,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: Site main depends on unavailable sets: t13-forms/sitepackage | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 56. Requested URL: https://t3-forms.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(28,1777629827,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: Site main depends on unavailable sets: t13-forms/sitepackage | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 56. Requested URL: https://t3-forms.ddev.site/favicon.ico',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(29,1777629828,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: Site main depends on unavailable sets: t13-forms/sitepackage | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 56. Requested URL: https://t3-forms.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(30,1777629828,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: Site main depends on unavailable sets: t13-forms/sitepackage | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 56. Requested URL: https://t3-forms.ddev.site/favicon.ico',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(31,1777629829,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: Site main depends on unavailable sets: t13-forms/sitepackage | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 56. Requested URL: https://t3-forms.ddev.site/',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(32,1777629829,0,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: #1607585445: Site main depends on unavailable sets: t13-forms/sitepackage | TYPO3\\CMS\\Core\\Error\\Http\\InternalServerErrorException thrown in file /var/www/html/vendor/typo3/cms-frontend/Classes/Controller/ErrorController.php in line 56. Requested URL: https://t3-forms.ddev.site/favicon.ico',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(33,1777630587,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(34,1777630659,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"mir\"]',-1,-99,'',0,'','info',NULL,NULL),
(35,1777630706,1,2,0,'site',0,0,'Site configuration \'%s\' was updated.',6,'site','172.18.0.5','[\"main\"]',-1,0,'',0,'','info',NULL,NULL),
(36,1777630715,1,2,2,'tt_content',0,0,'Record {table}:{uid} was updated',1,'content','172.18.0.5','{\"table\":\"tt_content\",\"uid\":2,\"history\":\"7\"}',1,0,'',0,'','info',NULL,NULL),
(37,1777630743,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"mir\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(38,1778570521,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\', password not accepted!',255,'user','','[\"mir\"]',-1,-99,'',0,'','info',NULL,NULL),
(39,1778570529,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"mir\"]',-1,-99,'',0,'','info',NULL,NULL),
(40,1778570663,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"mir\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(41,1778571261,1,1,2,'sys_file_storage',0,0,'Record {table}:{uid} was inserted on page {pid}',1,'content','172.18.0.5','{\"table\":\"sys_file_storage\",\"uid\":2,\"pid\":0}',0,0,'',0,'','info',NULL,NULL),
(42,1778571261,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'661853f2f9016',1778571261.7313,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(43,1778571262,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'e8aed4fe4ca5a',1778571262.9904,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(44,1778571264,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'864289c791936',1778571264.1645,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(45,1778571264,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'2ff724932fdf2',1778571264.6997,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(46,1778571272,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'f3495e72a4b9c',1778571272.6994,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(47,1778571273,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'e531103a78a83',1778571273.1597,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(48,1778571275,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'b6072e5619596',1778571275.3856,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(49,1778571276,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'d9e4cfebcfd78',1778571276.8875,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(50,1778571277,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'205f8bcf7aee5',1778571277.7197,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(51,1778571279,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'03ce14751ecc6',1778571279.4803,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(52,1778571281,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'f0cb42397c668',1778571281.2675,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(53,1778571425,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'1271647a1d4be',1778571425.3899,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(54,1778571426,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Too few arguments to function T13Forms\\Sitepackage\\Controller\\Backend\\OptionsImportController::__construct(), 0 passed in /var/www/html/vendor/typo3/cms-core/Classes/Utility/GeneralUtility.php on line 2885 and exactly 1 expected | ArgumentCountError thrown in file /var/www/html/packages/sitepackage/Classes/Controller/Backend/OptionsImportController.php in line 14. Requested URL: https://t3-forms.ddev.site/typo3/ajax/sitepackage/options-import/files?token=--AnonymizedToken--141fe08bcc0505857e86b902',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(55,1778571436,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'0aa2c68d51f8f',1778571436.1433,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(56,1778571437,1,0,0,'',0,2,'Core: Exception handler (WEB): Uncaught TYPO3 Exception: Too few arguments to function T13Forms\\Sitepackage\\Controller\\Backend\\OptionsImportController::__construct(), 0 passed in /var/www/html/vendor/typo3/cms-core/Classes/Utility/GeneralUtility.php on line 2885 and exactly 1 expected | ArgumentCountError thrown in file /var/www/html/packages/sitepackage/Classes/Controller/Backend/OptionsImportController.php in line 14. Requested URL: https://t3-forms.ddev.site/typo3/ajax/sitepackage/options-import/files?token=--AnonymizedToken--141fe08bcc0505857e86b902',5,'php','172.18.0.5','',-1,0,'',0,'','error',NULL,NULL),
(57,1778571662,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'c69bc423df5e5',1778571662.9767,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(58,1778571667,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'85158376ff288',1778571667.5758,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(59,1778571674,0,0,0,'',0,0,NULL,0,'default','',NULL,-1,0,'de033003cbc21',1778571674.0196,'TYPO3.CMS.Core.Resource.ResourceStorage','3','Failed initializing storage [2] \"options_providers\", error: Base path \"/var/www/html/public/options_providers/\" does not exist or is no directory.',''),
(60,1779052197,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"mir\"]',-1,-99,'',0,'','info',NULL,NULL),
(61,1779053789,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"mir\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(62,1779055209,1,1,0,'',0,0,'User {username} has cleared the cache (cacheCmd={command})',3,'default','172.18.0.5','{\"username\":\"mir\",\"command\":\"all\"}',-1,0,'',0,'','info',NULL,NULL),
(63,1779086084,0,3,0,'',0,3,'Login-attempt from ###IP###, username \'%s\' not found!',255,'user','','[\"admin\"]',-1,-99,'',0,'','info',NULL,NULL),
(64,1779086094,1,1,0,'',0,0,'User %s logged in from ###IP###',255,'user','','[\"mir\"]',-1,-99,'',0,'','info',NULL,NULL);
/*!40000 ALTER TABLE `sys_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_messenger_messages`
--

DROP TABLE IF EXISTS `sys_messenger_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_messenger_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `body` longtext NOT NULL,
  `headers` longtext NOT NULL,
  `queue_name` varchar(190) NOT NULL,
  `created_at` datetime NOT NULL,
  `available_at` datetime NOT NULL,
  `delivered_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `queue_name` (`queue_name`),
  KEY `available_at` (`available_at`),
  KEY `delivered_at` (`delivered_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_messenger_messages`
--

LOCK TABLES `sys_messenger_messages` WRITE;
/*!40000 ALTER TABLE `sys_messenger_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_messenger_messages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_news`
--

DROP TABLE IF EXISTS `sys_news`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_news` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `content` longtext DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_news`
--

LOCK TABLES `sys_news` WRITE;
/*!40000 ALTER TABLE `sys_news` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_news` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_note`
--

DROP TABLE IF EXISTS `sys_note`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_note` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `cruser` int(10) unsigned NOT NULL DEFAULT 0,
  `category` int(10) unsigned NOT NULL DEFAULT 0,
  `subject` varchar(255) NOT NULL DEFAULT '',
  `message` longtext DEFAULT NULL,
  `personal` smallint(5) unsigned NOT NULL DEFAULT 0,
  `position` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`deleted`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_note`
--

LOCK TABLES `sys_note` WRITE;
/*!40000 ALTER TABLE `sys_note` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_note` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_reaction`
--

DROP TABLE IF EXISTS `sys_reaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_reaction` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `impersonate_user` int(10) unsigned NOT NULL DEFAULT 0,
  `storage_pid` int(10) unsigned NOT NULL DEFAULT 0,
  `reaction_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `table_name` varchar(255) NOT NULL DEFAULT '',
  `fields` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`fields`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`reaction_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_reaction`
--

LOCK TABLES `sys_reaction` WRITE;
/*!40000 ALTER TABLE `sys_reaction` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_reaction` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_refindex`
--

DROP TABLE IF EXISTS `sys_refindex`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_refindex` (
  `hash` varchar(32) CHARACTER SET ascii COLLATE ascii_bin NOT NULL DEFAULT '',
  `tablename` varchar(64) NOT NULL DEFAULT '',
  `recuid` int(10) unsigned NOT NULL DEFAULT 0,
  `field` varchar(64) NOT NULL DEFAULT '',
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `flexpointer` varchar(255) NOT NULL DEFAULT '',
  `softref_key` varchar(30) NOT NULL DEFAULT '',
  `softref_id` varchar(40) NOT NULL DEFAULT '',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `workspace` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_table` varchar(64) NOT NULL DEFAULT '',
  `ref_uid` int(11) NOT NULL DEFAULT 0,
  `ref_field` varchar(64) NOT NULL DEFAULT '',
  `ref_hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `ref_starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_endtime` int(10) unsigned NOT NULL DEFAULT 2147483647,
  `ref_t3ver_state` int(10) unsigned NOT NULL DEFAULT 0,
  `ref_sorting` int(11) NOT NULL DEFAULT 0,
  `ref_string` varchar(1024) NOT NULL DEFAULT '',
  PRIMARY KEY (`hash`),
  KEY `lookup_rec` (`tablename`,`recuid`,`field`,`workspace`,`ref_t3ver_state`,`ref_hidden`,`ref_starttime`,`ref_endtime`),
  KEY `lookup_ref` (`ref_table`,`ref_uid`,`tablename`,`workspace`,`t3ver_state`,`hidden`,`starttime`,`endtime`),
  KEY `lookup_string` (`ref_string`(191)),
  KEY `idx_softref_key` (`softref_key`,`ref_uid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_refindex`
--

LOCK TABLES `sys_refindex` WRITE;
/*!40000 ALTER TABLE `sys_refindex` DISABLE KEYS */;
INSERT INTO `sys_refindex` VALUES
('64b2a394e0c1aa7126a38e5bebdb72a5','sys_file',8,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('662118c0b7a0096482db813011801a45','sys_file',1,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('77c1b13d2222b2a264bf63ae39a484d0','sys_file',9,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('77e6b72e292b433faf9e6bedef059a4a','tt_content',2,'pi_flexform',0,0,2147483647,0,'sDEF/lDEF/settings.persistenceIdentifier/vDEF/','formPersistenceIdentifier','a1be9f0b8031b85c35bf254795af5f6d',0,0,'sys_file',1,'',0,0,2147483647,0,0,''),
('786e131be796ac4b5888c15f165f7546','sys_file',7,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('a584c675c94a1ae29e74f647cdb8e3b3','sys_file',4,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('ad92a7d4a0b5d864fcd31905c0791f3b','sys_file',5,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('b29f51a7f7e6e6dcc6d99be7849ae442','sys_file',2,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('bee7419b079bf1311d4a280440fd7887','sys_file',1,'metadata',0,0,2147483647,0,'','','',0,0,'sys_file_metadata',1,'',0,0,2147483647,0,0,''),
('d762da2cbea3fc2bcaf1db96ded74dd7','sys_file',3,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,''),
('f65a0036c032c205fbec731c7f9abb9d','sys_file',6,'storage',0,0,2147483647,0,'','','',0,0,'sys_file_storage',1,'',0,0,2147483647,0,0,'');
/*!40000 ALTER TABLE `sys_refindex` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_registry`
--

DROP TABLE IF EXISTS `sys_registry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_registry` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_namespace` varchar(128) NOT NULL DEFAULT '',
  `entry_key` varchar(128) NOT NULL DEFAULT '',
  `entry_value` mediumblob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  UNIQUE KEY `entry_identifier` (`entry_namespace`,`entry_key`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_registry`
--

LOCK TABLES `sys_registry` WRITE;
/*!40000 ALTER TABLE `sys_registry` DISABLE KEYS */;
INSERT INTO `sys_registry` VALUES
(1,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\BackendUserLanguageMigration','i:1;'),
(2,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\MigrateExtensionDataImportRegistryKeysUpdate','i:1;'),
(3,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PageDoktypeLinkMigration','i:1;'),
(4,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\PagesRecyclerDoktypeMigration','i:1;'),
(5,'installUpdate','TYPO3\\CMS\\Core\\Upgrades\\UserPermissionsForRenamedModulesMigration','i:1;'),
(6,'installUpdate','TYPO3\\CMS\\Frontend\\Upgrades\\SynchronizeColPosAndCTypeWithDefaultLanguage','i:1;'),
(7,'installUpdate','TYPO3\\CMS\\Form\\Upgrades\\FileFormsToDatabaseUpgradeWizard','i:1;'),
(8,'installUpdate','TYPO3\\CMS\\Setup\\Upgrades\\UserSettingsMigration','i:1;'),
(9,'installUpdate','TYPO3\\CMS\\SysNote\\Migration\\SysNoteDashboardWidgetDatabaseMigration','i:1;'),
(10,'installUpdateRows','rowUpdatersDone','a:0:{}'),
(11,'core','formProtectionSessionToken:1','s:64:\"eb8d6b0b96ed79d5ba1f3ff03a79f29f3667070f527056cb612e2a41bf0bb86c\";'),
(12,'extensionDataImport','core:ext_tables_static+adt.sql','s:0:\"\";'),
(13,'extensionDataImport','extbase:ext_tables_static+adt.sql','s:0:\"\";'),
(14,'extensionDataImport','fluid:ext_tables_static+adt.sql','s:0:\"\";'),
(15,'extensionDataImport','install:ext_tables_static+adt.sql','s:0:\"\";'),
(16,'extensionDataImport','backend:ext_tables_static+adt.sql','s:0:\"\";'),
(17,'extensionDataImport','frontend:ext_tables_static+adt.sql','s:0:\"\";'),
(18,'extensionDataImport','dashboard:ext_tables_static+adt.sql','s:0:\"\";'),
(19,'extensionDataImport','fluid_styled_content:ext_tables_static+adt.sql','s:0:\"\";'),
(20,'extensionDataImport','filelist:ext_tables_static+adt.sql','s:0:\"\";'),
(21,'extensionDataImport','impexp:ext_tables_static+adt.sql','s:0:\"\";'),
(22,'extensionDataImport','form:ext_tables_static+adt.sql','s:0:\"\";'),
(23,'extensionDataImport','seo:ext_tables_static+adt.sql','s:0:\"\";'),
(24,'extensionDataImport','sys_note:ext_tables_static+adt.sql','s:0:\"\";'),
(25,'extensionDataImport','belog:ext_tables_static+adt.sql','s:0:\"\";'),
(26,'extensionDataImport','beuser:ext_tables_static+adt.sql','s:0:\"\";'),
(27,'extensionDataImport','felogin:ext_tables_static+adt.sql','s:0:\"\";'),
(28,'extensionDataImport','info:ext_tables_static+adt.sql','s:0:\"\";'),
(29,'extensionDataImport','reactions:ext_tables_static+adt.sql','s:0:\"\";'),
(30,'extensionDataImport','recycler:ext_tables_static+adt.sql','s:0:\"\";'),
(31,'extensionDataImport','rte_ckeditor:ext_tables_static+adt.sql','s:0:\"\";'),
(32,'extensionDataImport','tstemplate:ext_tables_static+adt.sql','s:0:\"\";'),
(33,'extensionDataImport','viewpage:ext_tables_static+adt.sql','s:0:\"\";'),
(34,'extensionDataImport','webhooks:ext_tables_static+adt.sql','s:0:\"\";'),
(35,'extensionDataImport','vite_asset_collector:ext_tables_static+adt.sql','s:0:\"\";'),
(36,'extensionDataImport','sitepackage:ext_tables_static+adt.sql','s:0:\"\";');
/*!40000 ALTER TABLE `sys_registry` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_template`
--

DROP TABLE IF EXISTS `sys_template`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_template` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `sorting` int(11) NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `root` smallint(5) unsigned NOT NULL DEFAULT 0,
  `clear` smallint(5) unsigned NOT NULL DEFAULT 0,
  `constants` longtext DEFAULT NULL,
  `include_static_file` longtext DEFAULT NULL,
  `basedOn` longtext DEFAULT NULL,
  `includeStaticAfterBasedOn` smallint(5) unsigned NOT NULL DEFAULT 0,
  `config` longtext DEFAULT NULL,
  `static_file_mode` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `roottemplate` (`deleted`,`hidden`,`root`),
  KEY `parent` (`pid`,`deleted`,`hidden`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_template`
--

LOCK TABLES `sys_template` WRITE;
/*!40000 ALTER TABLE `sys_template` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_template` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sys_webhook`
--

DROP TABLE IF EXISTS `sys_webhook`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sys_webhook` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `updatedon` int(10) unsigned NOT NULL DEFAULT 0,
  `createdon` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `disabled` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `description` text DEFAULT NULL,
  `webhook_type` varchar(255) NOT NULL DEFAULT '',
  `name` varchar(100) NOT NULL DEFAULT '',
  `identifier` char(36) NOT NULL COMMENT '(DC2Type:guid)',
  `secret` varchar(255) NOT NULL DEFAULT '',
  `url` text NOT NULL DEFAULT '',
  `method` varchar(10) NOT NULL DEFAULT '',
  `verify_ssl` smallint(5) unsigned NOT NULL DEFAULT 1,
  `additional_headers` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`additional_headers`)),
  PRIMARY KEY (`uid`),
  UNIQUE KEY `identifier_key` (`identifier`),
  KEY `index_source` (`webhook_type`(5)),
  KEY `parent` (`pid`,`deleted`,`disabled`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sys_webhook`
--

LOCK TABLES `sys_webhook` WRITE;
/*!40000 ALTER TABLE `sys_webhook` DISABLE KEYS */;
/*!40000 ALTER TABLE `sys_webhook` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tt_content`
--

DROP TABLE IF EXISTS `tt_content`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tt_content` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `deleted` smallint(5) unsigned NOT NULL DEFAULT 0,
  `hidden` smallint(5) unsigned NOT NULL DEFAULT 0,
  `starttime` int(10) unsigned NOT NULL DEFAULT 0,
  `endtime` int(10) unsigned NOT NULL DEFAULT 0,
  `fe_group` varchar(255) NOT NULL DEFAULT '0',
  `sorting` int(11) NOT NULL DEFAULT 0,
  `rowDescription` text DEFAULT NULL,
  `editlock` smallint(5) unsigned NOT NULL DEFAULT 0,
  `sys_language_uid` int(11) NOT NULL DEFAULT 0,
  `l18n_parent` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_source` int(10) unsigned NOT NULL DEFAULT 0,
  `l10n_state` text DEFAULT NULL,
  `l18n_diffsource` mediumblob DEFAULT NULL,
  `t3ver_oid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_wsid` int(10) unsigned NOT NULL DEFAULT 0,
  `t3ver_state` smallint(6) NOT NULL DEFAULT 0,
  `t3ver_stage` int(11) NOT NULL DEFAULT 0,
  `frame_class` varchar(60) NOT NULL DEFAULT 'default',
  `colPos` int(10) unsigned NOT NULL DEFAULT 0,
  `table_caption` varchar(255) DEFAULT NULL,
  `tx_impexp_origuid` int(11) NOT NULL DEFAULT 0,
  `CType` varchar(255) NOT NULL DEFAULT 'text',
  `categories` int(10) unsigned NOT NULL DEFAULT 0,
  `layout` int(10) unsigned NOT NULL DEFAULT 0,
  `space_before_class` varchar(60) NOT NULL DEFAULT '',
  `space_after_class` varchar(60) NOT NULL DEFAULT '',
  `date` bigint(20) NOT NULL DEFAULT 0,
  `header` varchar(255) NOT NULL DEFAULT '',
  `header_layout` int(10) unsigned NOT NULL DEFAULT 0,
  `header_position` varchar(255) NOT NULL DEFAULT '',
  `header_link` text NOT NULL DEFAULT '',
  `subheader` varchar(255) NOT NULL DEFAULT '',
  `bodytext` longtext DEFAULT NULL,
  `image` int(10) unsigned NOT NULL DEFAULT 0,
  `assets` int(10) unsigned NOT NULL DEFAULT 0,
  `imagewidth` int(10) unsigned DEFAULT NULL,
  `imageheight` int(10) unsigned DEFAULT NULL,
  `imageorient` int(10) unsigned NOT NULL DEFAULT 0,
  `imageborder` smallint(5) unsigned NOT NULL DEFAULT 0,
  `image_zoom` smallint(5) unsigned NOT NULL DEFAULT 0,
  `imagecols` int(10) unsigned NOT NULL DEFAULT 2,
  `pages` longtext DEFAULT NULL,
  `recursive` int(10) unsigned NOT NULL DEFAULT 0,
  `media` int(10) unsigned NOT NULL DEFAULT 0,
  `records` longtext DEFAULT NULL,
  `sectionIndex` smallint(5) unsigned NOT NULL DEFAULT 1,
  `linkToTop` smallint(5) unsigned NOT NULL DEFAULT 0,
  `pi_flexform` longtext DEFAULT NULL,
  `selected_categories` longtext DEFAULT NULL,
  `category_field` varchar(64) NOT NULL DEFAULT '',
  `bullets_type` int(10) unsigned NOT NULL DEFAULT 0,
  `cols` int(10) unsigned NOT NULL DEFAULT 0,
  `table_class` varchar(60) NOT NULL DEFAULT '',
  `table_delimiter` int(10) unsigned NOT NULL DEFAULT 124,
  `table_enclosure` int(10) unsigned NOT NULL DEFAULT 0,
  `table_header_position` int(10) unsigned NOT NULL DEFAULT 0,
  `table_tfoot` smallint(5) unsigned NOT NULL DEFAULT 0,
  `file_collections` longtext DEFAULT NULL,
  `filelink_size` smallint(5) unsigned NOT NULL DEFAULT 0,
  `filelink_sorting` varchar(64) NOT NULL DEFAULT '',
  `filelink_sorting_direction` varchar(4) NOT NULL DEFAULT '',
  `target` varchar(30) NOT NULL DEFAULT '',
  `uploads_description` smallint(5) unsigned NOT NULL DEFAULT 0,
  `uploads_type` int(10) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`uid`),
  KEY `parent` (`pid`,`sorting`),
  KEY `language_identifier` (`l18n_parent`,`sys_language_uid`),
  KEY `translation_source` (`l10n_source`),
  KEY `t3ver_oid` (`t3ver_oid`,`t3ver_wsid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tt_content`
--

LOCK TABLES `tt_content` WRITE;
/*!40000 ALTER TABLE `tt_content` DISABLE KEYS */;
INSERT INTO `tt_content` VALUES
(1,1,1776096069,1776096069,0,0,0,0,'0',0,NULL,0,0,0,0,NULL,NULL,0,0,0,0,'default',0,NULL,0,'text',0,0,'','',0,'Welcome to your default website',0,'','','','<p>This website is made with <a href=\"https://typo3.org\" target=\"_blank\">TYPO3</a>.</p>',0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,NULL,NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0),
(2,1,1777630715,1776096632,0,0,0,0,'0',256,'',0,0,0,0,NULL,'{\"CType\":\"\",\"colPos\":\"\",\"date\":\"\",\"editlock\":\"\",\"endtime\":\"\",\"frame_class\":\"\",\"header\":\"\",\"header_layout\":\"\",\"header_link\":\"\",\"header_position\":\"\",\"hidden\":\"\",\"layout\":\"\",\"linkToTop\":\"\",\"pi_flexform\":\"\",\"rowDescription\":\"\",\"sectionIndex\":\"\",\"space_after_class\":\"\",\"space_before_class\":\"\",\"starttime\":\"\",\"subheader\":\"\"}',0,0,0,0,'default',0,NULL,0,'form_formframework',0,0,'','',0,'',0,'','','',NULL,0,0,NULL,NULL,0,0,0,2,NULL,0,0,NULL,1,0,'<?xml version=\"1.0\" encoding=\"utf-8\" standalone=\"yes\" ?>\n<T3FlexForms>\n    <data>\n        <sheet index=\"sDEF\">\n            <language index=\"lDEF\">\n                <field index=\"settings.persistenceIdentifier\">\n                    <value index=\"vDEF\">1:/form_definitions/ert.form.yaml</value>\n                </field>\n                <field index=\"settings.overrideFinishers\">\n                    <value index=\"vDEF\">0</value>\n                </field>\n                <field index=\"settings.useAjax\">\n                    <value index=\"vDEF\">1</value>\n                </field>\n            </language>\n        </sheet>\n    </data>\n</T3FlexForms>',NULL,'',0,0,'',124,0,0,0,NULL,0,'','','',0,0);
/*!40000 ALTER TABLE `tt_content` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tx_impexp_presets`
--

DROP TABLE IF EXISTS `tx_impexp_presets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tx_impexp_presets` (
  `uid` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `pid` int(10) unsigned NOT NULL DEFAULT 0,
  `tstamp` int(10) unsigned NOT NULL DEFAULT 0,
  `crdate` int(10) unsigned NOT NULL DEFAULT 0,
  `title` varchar(255) NOT NULL DEFAULT '',
  `public` smallint(6) NOT NULL DEFAULT 0,
  `item_uid` int(11) NOT NULL DEFAULT 0,
  `user_uid` int(10) unsigned NOT NULL DEFAULT 0,
  `preset_data` blob DEFAULT NULL,
  PRIMARY KEY (`uid`),
  KEY `lookup` (`item_uid`),
  KEY `parent` (`pid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tx_impexp_presets`
--

LOCK TABLES `tx_impexp_presets` WRITE;
/*!40000 ALTER TABLE `tx_impexp_presets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tx_impexp_presets` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-05-22  9:13:41
